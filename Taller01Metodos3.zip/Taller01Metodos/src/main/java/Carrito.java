/*
 *Metodos a utilizar:
 * -GenerarCeldas: genera la celdas randomizadas de entre 1 y 20 de largo(Retorna las celadas)**
 * -AsignarPrecios: dependiendo de la cantidad de celdas añade precios ascendentes de 150 en 150 comenzando por 500 (retorna las celdas con sus valores)
 * -CantidadProducto: puede tener entre 0 y 15 productos por celda, aleatorio.(Retorna la cantidad de producto comprado)
 * -MostrarProducto: Muestra la cantidad de producto llevado
 * -PreciosProductos: Multiplica el precio por la cantidad de productos(Retorna el total de cada producto)
 * -SumaTotal: Suma todos los valores para sacar el total
 * -MostrarTotal: Muesta la suma total de los productos
 *
 *
 *
 *
 *Mult carrito sub i por el precio(multiplico sumo y acumulo)
 *
 * */


public class Carrito {
    public static void main(String[] args) {
        int Arreglo[] = new int[(int) (Math.random() * (20 - 1) + 1)];
        int Precios[] = Arreglo.clone();
        GenerarArreglo(Arreglo);
        AsignarPrecios(Arreglo);
        MostrarProducto(Arreglo, Precios);

    }

    public static int[] GenerarArreglo(int Arreglo[]) {

        for (int i = 0; i < Arreglo.length; i++) {
            System.out.println();
            //System.out.print("Producto [" + i + "] ");
        }
        return Arreglo;
    }

    public static int[] AsignarPrecios(int Precios[]) {
        int precioInicial = 500;
        for (int j = 0; j < Precios.length; j++) {

            Precios[j] = (int) (Math.random() * (500 - 1) + 150);

            // System.out.println(Precios[[i]]);
        }
        return Precios;


    }

    public static void MostrarProducto(int Arreglo[], int Precios[]) {

        System.out.println();
        for (int i = 0; i < Arreglo.length; i++) {
            for (int j = 0; j < Precios.length; j++) {
                System.out.println();
                System.out.print("Producto [" + i + "] " + "con precio de:" + j);


            }
            return;

        }
    }
}



