/*
*Metodos a utilizar:
* -GenerarCeldas: genera la celdas randomizadas de entre 1 y 20 de largo(Retorna las celadas)
* -AsignarPrecios: dependiendo de la cantidad de celdas añade precios ascendentes de 150 en 150 comenzando por 500 (retorna las celdas con sus valores)
* -CantidadProducto: puede tener entre 0 y 15 productos por celda, aleatorio.(Retorna la cantidad de producto comprado)
* -MostrarProducto: Muestra la cantidad de producto llevado
* -PreciosProductos: Multiplica el precio por la cantidad de productos(Retorna el total de cada producto)
* -SumaTotal: Suma todos los valores para sacar el total
* -MostrarTotal: Muesta la suma total de los productos
*
*
*
*
*Mult carrito sub i por el precio(multiplico sumo y acumulo)
*
* */


public class Carrito {
    public static void main(String[] args) {




    }






}
